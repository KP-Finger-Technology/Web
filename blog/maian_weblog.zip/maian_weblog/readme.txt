Welcome to MAIAN WEBLOG.
------------------------------------

Thank you for downloading the latest version of Maian Weblog, a free blog system released
under the 'Creative Commons Attribution 2.5 Licence. This script is free to use for both commercial and 
non-commercial purposes provided you link back to maianscriptworld.co.uk. See the following for more
information:

publish/docs/licence.txt


Installation:
----------------------------

For installation instructions, information, frequently asked questions and support,
please open the following url (located in the .zip you downloaded) in your browser:


publish/docs/setup/index.html


Language packs:
----------------------------

If you would like to submit a language pack, please email it to me at:
support@maianscriptworld.co.uk


I hope you enjoy your new blog system.

David Ian Bennett

---------------------------------------------------------------
Maian Weblog. Copyright � David Ian Bennett. All Rights Reserved.
http://www.maianweblog.com

Maian Script World
http://www.maianscriptworld.co.uk

Latest news and server status:
https://twitter.com/#!/maianscripts
