
      
      <!-- Main Content Div -->
      <div id="content">
       <?php echo $this->LATEST_POSTS; ?>
      </div>
      <!-- End Main Content Div -->
    

