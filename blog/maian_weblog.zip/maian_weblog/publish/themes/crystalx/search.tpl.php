
      
      <!-- Search Data Display -->
      <div id="content">
       <?php echo $this->SEARCH_DATA; ?>
       <?php echo $this->PAGE_NUMBERS; ?>
       </div>
       <hr class="noscreen" />
      </div>
      <!-- End Search Data Display -->
    

