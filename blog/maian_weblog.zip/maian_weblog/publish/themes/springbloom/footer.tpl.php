  </div>
<div id="footer">
	<p><?php echo $this->FOOTER; ?> | Design: <a href="http://www.edg3.co.uk/" title="edg3.co.uk">edg3.co.uk</a></p>
</div>

<!-- Snap Code -->
<?php echo $this->SNAP_CODE; ?>
<!-- End Snap Code -->

</body>
</html>
