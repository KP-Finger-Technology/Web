=========================
E-MAIL TEMPLATE VARIABLES
=========================

The following variables may be used in the notification e-mail template:

{BLOGTITLE}    =  Blog title
{BLOGURL}      =  Blog Url
{COMMENTS}     =  Visitor comment
{VISITOR}      =  Visitor name
{EMAIL}        =  Visitor e-mail address
{IP}           =  Visitor IP address
{DATE}         =  Date comment posted
{SITEPATH}     =  Installation path as specified in settings

The following variables may be used in the tell a friend e-mail template:

{BLOGTITLE}    =  Blog title
{BLOGURL}      =  Blog Url
{COMMENTS}     =  Visitor comment
{VISITOR}      =  Visitor name
{FRIEND}       =  Friend name
{DATE}         =  Date comment sent
{WEBSITE}      =  Name of website as specified in settings
{WEBSITE_URL}  =  Path to blog as specified in settings

If you have any problems please see the support options in the docs.
