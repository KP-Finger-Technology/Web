    </div>
    <!-- End Content Wrapper -->
    
    <!-- Footer -->
    <div id="footer">
     <p><?php echo $this->FOOTER; ?></p>
    </div>
    <!-- End Footer -->

</div>
<!-- End System Wrapper -->

<!-- Snap Code -->
<?php echo $this->SNAP_CODE; ?>
<!-- End Snap Code -->

</body>
</html>
