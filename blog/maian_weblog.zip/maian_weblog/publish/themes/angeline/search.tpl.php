
      
      <!-- Search Data Display -->
      <div class="content">
       <?php echo $this->SEARCH_DATA; ?>
       <?php echo $this->PAGE_NUMBERS; ?>
      </div>
      <!-- End Search Data Display -->
    

