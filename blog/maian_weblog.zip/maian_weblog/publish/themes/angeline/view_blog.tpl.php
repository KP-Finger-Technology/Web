
      
      <!-- Main Content Div -->
      <div class="content">
       <?php echo $this->BLOG_DATA; ?>
       <div class="comments">
        <?php echo $this->COMMENT_DATA; ?>
       </div>
       <?php echo $this->REPLY_BOX; ?>
      </div>
      <!-- End Main Content Div -->
    

