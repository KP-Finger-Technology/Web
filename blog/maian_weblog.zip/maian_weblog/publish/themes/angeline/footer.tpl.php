        <!-- End content -->
          
        </div>
        <br class="clear" />
      </div>
      <br class="clear" />
      <div id="footer">
        <div id="footHead">
		    <div class="clear"></div>
        </div>
        <div id="footBody">
		    <div class="clear"></div>
         <div id="copyright">
          <div class="container">
          <?php echo $this->FOOTER; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          Design: <a href="http://aaron.ganschow.us/" title="Aaron Ganschow">Aaron Ganschow</a>
          </div>
        </div>
      </div>
  </div>
</div>
<!-- End System Wrapper -->

<!-- Snap Code -->
<?php echo $this->SNAP_CODE; ?>
<!-- End Snap Code -->

</body>
</html>
