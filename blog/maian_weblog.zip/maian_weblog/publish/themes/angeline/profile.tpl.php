
      
      <!-- Main Content Div -->
      <div class="content">
       <?php echo $this->PROFILE; ?>
      </div>
      <!-- End Main Content Div -->
    

