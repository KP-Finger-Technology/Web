
      
      <!-- Main Content Div -->
      <?php echo $this->LATEST_POSTS; ?>
      <!-- End Main Content Div -->
    

