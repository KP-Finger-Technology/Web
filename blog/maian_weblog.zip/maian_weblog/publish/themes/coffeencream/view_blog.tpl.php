
      
      <!-- Main Content Div -->
      <?php echo $this->BLOG_DATA; ?>
      <?php echo $this->COMMENT_DATA; ?>
      <?php echo $this->REPLY_BOX; ?>
      <!-- End Main Content Div -->
    

