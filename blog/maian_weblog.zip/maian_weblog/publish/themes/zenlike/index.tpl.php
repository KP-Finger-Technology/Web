
      
      <!-- Main Content Div -->
      <div id="primarycontainer">
        <div id="primarycontent">
        <?php echo $this->LATEST_POSTS; ?>
        </div>
      </div>
      <!-- End Main Content Div -->
    

