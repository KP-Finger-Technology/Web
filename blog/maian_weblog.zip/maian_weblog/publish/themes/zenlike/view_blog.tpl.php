
      
      <!-- Main Content Div -->
      <div id="primarycontainer">
        <div id="primarycontent">
        <?php echo $this->BLOG_DATA; ?>
        <?php echo $this->COMMENT_DATA; ?>
        <?php echo $this->REPLY_BOX; ?>
        </div>
      </div>
      <!-- End Main Content Div -->
    

