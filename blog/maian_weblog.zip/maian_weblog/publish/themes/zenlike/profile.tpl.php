
      
      <!-- Main Content Div -->
      <div id="primarycontainer">
        <div id="primarycontent">
        <?php echo $this->PROFILE; ?>
        </div>
      </div>
      <!-- End Main Content Div -->
    

