
      
      <!-- Search Data Display -->
      <div id="primarycontainer">
        <div id="primarycontent">
        <?php echo $this->SEARCH_DATA; ?>
        <?php echo $this->PAGE_NUMBERS; ?>
        </div>
      </div>
      <!-- End Search Data Display -->
    

