	</div>

	<div id="footer">
			<div class="left"><?php echo $this->FOOTER; ?></div>
			<div class="right">Design: <a href="http://www.nodethirtythree.com/" title="NodeThirtyThree Design">NodeThirtyThree Design</a></div>
	</div>
	
</div>

<!-- Snap Code -->
<?php echo $this->SNAP_CODE; ?>
<!-- End Snap Code -->

</body>
</html>
