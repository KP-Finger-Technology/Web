
      
      <!-- Main Content Div -->
      <div id="column2">
       <?php echo $this->BLOG_DATA; ?>
       <?php echo $this->COMMENT_DATA; ?>
       <?php echo $this->REPLY_BOX; ?>
      </div>
      <!-- End Main Content Div -->
    

