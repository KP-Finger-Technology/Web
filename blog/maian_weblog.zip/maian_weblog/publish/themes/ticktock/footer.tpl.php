    </div>
    <div id="footer">
      <?php echo $this->FOOTER; ?> | Design: <a href="http://www.dcarter.co.uk" title="dcarter">dcarter</a>
    </div>
  </div>
<!-- End System Wrapper -->

<!-- Snap Code -->
<?php echo $this->SNAP_CODE; ?>
<!-- End Snap Code -->

</body>
</html>
