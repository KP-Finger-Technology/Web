
      
      <!-- Main Content Div -->
      <div id="column2">
       <?php echo $this->PROFILE; ?>
      </div>
      <!-- End Main Content Div -->
    

