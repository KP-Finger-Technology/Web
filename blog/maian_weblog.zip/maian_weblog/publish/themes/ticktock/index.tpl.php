
      
      <!-- Main Content Div -->
      <div id="column2">
       <?php echo $this->LATEST_POSTS; ?>
      </div>
      <!-- End Main Content Div -->
    

