
      
      <!-- Search Data Display -->
      <div id="main">
       <?php echo $this->SEARCH_DATA; ?>
       <?php echo $this->PAGE_NUMBERS; ?>
      </div>
      <!-- End Search Data Display -->
    

