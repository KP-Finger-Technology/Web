
      
      <!-- Main Content Div -->
      <div id="main">
       <?php echo $this->LATEST_POSTS; ?>
      </div>
      <!-- End Main Content Div -->
    

