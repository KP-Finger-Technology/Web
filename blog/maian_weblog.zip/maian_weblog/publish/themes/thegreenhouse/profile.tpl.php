
      
      <!-- Main Content Div -->
      <div id="posts">
       <?php echo $this->PROFILE; ?>
      </div>
      <!-- End Main Content Div -->
    

