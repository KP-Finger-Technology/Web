    <div style="clear: both;">&nbsp;</div>
	</div>
</div>
<!-- end #content -->
<div id="footer">
	<p id="legal"><?php echo $this->FOOTER; ?><br />Design: <a href="http://www.freecsstemplates.org/" title="Free CSS Templates">Free CSS Templates</a></p>
	<p id="brand">&nbsp;</p>
</div>
<!-- end #footer -->

<!-- Snap Code -->
<?php echo $this->SNAP_CODE; ?>
<!-- End Snap Code -->

</body>
</html>
