
      
      <!-- Main Content Div -->
      <div id="posts">
       <?php echo $this->BLOG_DATA; ?>
       <div class="post">
        <h2 class="title"><?php echo $this->COMMENT_COUNT; ?></h2>
        <?php echo $this->COMMENT_DATA; ?>
       </div> 
       <?php echo $this->REPLY_BOX; ?>
      </div>
      <!-- End Main Content Div -->
    

