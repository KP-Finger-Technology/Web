<?php

/*---------------------------------------------
  MAIAN WEBLOG v4.0
  Written by David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: www.maianscriptworld.co.uk
  This File: Admin - Password/Username
----------------------------------------------*/


//-----------------------------
//Username
//Specify account username
//-----------------------------

$admin_username     = encrypt('username goes here');

//-----------------------------
//Password
//Specify account password
//-----------------------------

$admin_password      = encrypt('password goes here');

?>
