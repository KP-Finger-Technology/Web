<?php

/*---------------------------------------------
  MAIAN WEBLOG v4.0
  Written by David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: www.maianscriptworld.co.uk
  This File: Administration Footer
----------------------------------------------*/

if (!defined('PARENT')) {
  exit;
} 

?>
<!-- END TEMPLATE -->
</table>
</div>
<p align="center" class="copyright"><b><?php echo $msg_script3; ?></b>: <a href="http://www.maianweblog.com/" title="<?php echo $msg_script." ".$msg_script2; ?>" target="_blank"><?php echo $msg_script." ".$msg_script2; ?></a><br>&copy; <?php echo '2005-'.date("Y"); ?> Maian Script World. <?php echo $msg_script14; ?></p>
</body>
</html>
