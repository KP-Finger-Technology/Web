YouTube Plugin for SPAW Editor PHP Edition v.2
--------------------------------------------------
Embeds YouTube movie into the content based on YouTube page URL.

Installation
------------
Just copy "youtube" directory into "plugins" subdir of your SPAW v.2 
installation. 

Configuration
-------------
No configuration is needed.

Copyright
---------
This plugin is (c)2007 by UAB Solmetra.
It is released under terms of GNU General Public License (see license.txt in
"docs" subdirectory)

Commercial SPAW license owners can use this plugin free of charge under the terms
of their respective license.
