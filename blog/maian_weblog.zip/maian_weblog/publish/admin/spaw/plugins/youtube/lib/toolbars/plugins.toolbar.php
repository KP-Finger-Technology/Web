<?php
$items = array
(
  new SpawTbButton('youtube', 'youtube_prop', 'isYouTubePropEnabled', '', 'youTubePropClick'),
);
?>
