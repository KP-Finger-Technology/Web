<?php
/**
* 
* Template for testing token references.
* 
* @version $Id: assign.tpl.php,v 1.1 2004/10/04 01:52:24 pmjones Exp $
*
*/

?>
<h1>Change reference values from template</h1>
<p>Before: <?php echo $this->reference; $this->reference = "Changed Value From Template!" ?></p>
