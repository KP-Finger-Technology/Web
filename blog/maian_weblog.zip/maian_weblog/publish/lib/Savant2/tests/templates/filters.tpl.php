<?php
/**
* 
* Tests the default and example filters for Savant.
* 
* @version $Id: filters.tpl.php,v 1.1 2004/10/04 01:52:24 pmjones Exp $
*
*/
?>


<h1>Filters</h1>





<p>This and that</p>






<p>And the other</p>



<pre><code>
<php>
	// this is a test of PHP colorizing
	echo "some text";
	highlight_string("something");
	$variable = 'value';
	
	function fester()
	{
		// does nothing
	}
</php>
</code></pre>


<!-- end -->